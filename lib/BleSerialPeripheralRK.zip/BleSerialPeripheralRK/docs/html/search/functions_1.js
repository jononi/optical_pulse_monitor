var searchData=
[
  ['bleserialperipheralbase',['BleSerialPeripheralBase',['../class_ble_serial_peripheral_base.html#a1c1811adb8b03e7c0cb6e5f6c0a42fab',1,'BleSerialPeripheralBase']]]
];
