var searchData=
[
  ['advertise',['advertise',['../class_ble_serial_peripheral_base.html#a870258aa62e285cc0e2717476ae51145',1,'BleSerialPeripheralBase']]],
  ['available',['available',['../class_ble_serial_peripheral_base.html#a946cc56677f03db99de9409851427941',1,'BleSerialPeripheralBase::available()'],['../class_stream.html#a9c98a763395005c08ce95afb2f06c7b1',1,'Stream::available()']]],
  ['availableforread',['availableForRead',['../class_ring_buffer.html#a2d77169348cd228b343ba2245e1ce371',1,'RingBuffer']]]
];
