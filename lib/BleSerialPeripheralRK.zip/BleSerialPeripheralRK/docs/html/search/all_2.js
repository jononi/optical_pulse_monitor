var searchData=
[
  ['clearrxlost',['clearRxLost',['../class_ble_serial_peripheral_base.html#af2dc5ee170da6783176ce6c96456fdb4',1,'BleSerialPeripheralBase']]],
  ['cleartxlost',['clearTxLost',['../class_ble_serial_peripheral_base.html#a3f7273afa5985d6df935b530d9550b6c',1,'BleSerialPeripheralBase']]],
  ['clearwriteerror',['clearWriteError',['../class_print.html#aec9ecf84cc6d9087a650def3cefc459e',1,'Print']]]
];
