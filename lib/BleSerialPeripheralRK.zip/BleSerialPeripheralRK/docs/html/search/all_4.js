var searchData=
[
  ['getrxlost',['getRxLost',['../class_ble_serial_peripheral_base.html#a97cee829a39ff3a62e3108f05fba64d8',1,'BleSerialPeripheralBase']]],
  ['getserviceuuid',['getServiceUuid',['../class_ble_serial_peripheral_base.html#a0457f2495023d47468a2f5b1964c0233',1,'BleSerialPeripheralBase']]],
  ['gettxlost',['getTxLost',['../class_ble_serial_peripheral_base.html#a09c779ad7767bc195687c525548127d9',1,'BleSerialPeripheralBase']]],
  ['gettxmaxwrite',['getTxMaxWrite',['../class_ble_serial_peripheral_base.html#aa4ca5408c166841e1fd5ea9aa3a1c4a5',1,'BleSerialPeripheralBase']]],
  ['getwriteerror',['getWriteError',['../class_print.html#a88a4a829fb5d589efb43955ad0cbddcc',1,'Print']]]
];
