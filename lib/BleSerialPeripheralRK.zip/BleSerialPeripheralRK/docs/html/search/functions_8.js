var searchData=
[
  ['settimeout',['setTimeout',['../class_stream.html#abaa50647d6dbb3baf7697a2691a06177',1,'Stream']]],
  ['settxmaxwrite',['setTxMaxWrite',['../class_ble_serial_peripheral_base.html#a454bb53617c96d564f3e20d13765de9f',1,'BleSerialPeripheralBase']]],
  ['setup',['setup',['../class_ble_serial_peripheral_base.html#a01072243aecf86ea5030019a6e900fbb',1,'BleSerialPeripheralBase']]]
];
